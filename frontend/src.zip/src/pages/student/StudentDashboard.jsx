import React, { useEffect, useState } from "react";
import "./dashboard.css";
const StudentDashboard = () => {
    const [student, setStudent] = useState(null);
    const [latestActivity, setLatestActivity] = useState(null);

    useEffect(() => {
        const fetchStudentData = async () => {
            try {
                const user = JSON.parse(localStorage.getItem('user'));
                const studentID = user?.studentID || "DefaultID"; 
    
                console.log("Student ID:", studentID); // Check if this is printed in the console
    
                const studentResponse = await fetch(`http://localhost:8080/api/student/${studentID}`);
                const studentData = await studentResponse.json();
                console.log('Student Data:', studentData); // Check if the data is received
    
                setStudent(studentData);
    
                const activityResponse = await fetch(`http://localhost:8080/api/student/${studentID}/activities`);
                const activityData = await activityResponse.json();
                if (activityData.length > 0) {
                    setLatestActivity(activityData[activityData.length - 1]);
                }
            } catch (error) {
                console.error("Error fetching student data:", error);
            }
        };
    
        fetchStudentData();
    }, []); // Empty dependency array ensures this effect runs once when component mounts
    

    return (
        <div>
            <h1 style={{marginLeft:"550px"}}>STUDENT PORTAL DASHBOARD</h1>
            {student && (
                <div>
                    <h3>Welcome back, {student.name || 'Student'}!</h3>
                    <p>{new Date().toLocaleDateString()} | {student.studentID}</p>
                </div>
            )}

            <div>
                <h2>Total Department Points: {student?.departmentPoints || 0}</h2>
                <h2>Total Institutional Points: {student?.institutionalPoints || 0}</h2>
                <h2>Total Activity Points: {student?.activityPoints || 0}</h2>
            </div>

            <h2>Activity History</h2>
            <table>
                <thead>
                    <tr>
                        <th>Activity Name</th>
                        <th>Institute or Departmental</th>
                        <th>Activity Points</th>
                    </tr>
                </thead>
                <tbody>
                    {latestActivity ? (
                        <tr>
                            <td>{latestActivity.name}</td>
                            <td>{latestActivity.type}</td>
                            <td>{latestActivity.points}</td>
                        </tr>
                    ) : (
                        <tr>
                            <td colSpan="3">No recent activity available</td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
    );
};

export default StudentDashboard;