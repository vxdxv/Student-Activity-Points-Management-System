import React from 'react'

const FaDashboard = () => {
  return (
    <div>
      
    </div>
  )
}

export default FaDashboard
