import React from 'react'
import './navbar.css'

const NavBar = () => {
  return (
    <div className='navbar'>
     <div className='navbar__left'>
        <h3>Name</h3>
      </div>
      <div className='navbar__right'> 
            {/* <h3>Name</h3> */}
      </div>
    </div>
  )
}

export default NavBar
